export interface ElxMethods {

}

/**
 * Extension component based on ElementUI 2.x.
 */
declare var VueElementExtends: ElxMethods;

export default VueElementExtends;