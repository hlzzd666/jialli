import Editable from './src/editable'

Editable.install = function (Vue) {
  Vue.component(Editable.name, Editable)
}

export default Editable
